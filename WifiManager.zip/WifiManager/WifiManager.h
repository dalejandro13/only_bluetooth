#ifndef WIFI_MANAGER
#define WIFI_MANAGER

#if defined(ESP8266)
#define HARDWARE "ESP8266"
#include <ESP8266WiFi.h>
#include <WiFiClient.h>
#include <ESP8266WebServer.h>
#elif defined(ESP32)
#define HARDWARE "ESP32"
#include <WiFi.h>
#include <WiFiClient.h>
#include <WebServer.h>
#endif
#include <WiFiUdp.h>
#include "ElegantOTA.h"

class WifiManager
{
public:
    // Constructors
    WifiManager();
    WifiManager(bool debug);

    /**************************
        CONNECTION TO STATIONS
    ***************************/

    // Connection Overlays (Just for connect to stations)
    void connect(String networkSSID, String networkPASS);
    void connect(char *networkSSID, char *networkPASS);

    // Disconnecto from stations
    void disconnect();

    // Check if is connected to any network
    bool isConnected();

    /*************************************
        CREATE & MANAGE ACCESS POINTS
    **************************************/
    // Simple Access Point Creation
    void createAP(String ssid, String pass);
    void createAP(char *ssid, char *pass);

    // Access Point creation using custom IP

    /*****************************
        MANAGE UDP SERVER
    ******************************/
    bool startUdpServer(unsigned int port);
    bool isDataAvailable();
    String getWifiData();
    char *getWifiDataInChars();
    void stopUdpServer();
    bool sendData(char *remoteIp, int remotePort, const byte *data, size_t size);
    bool sendData(char *remoteIp, int remotePort, String data);
    /*****************************
        MANAGE HTTP SERVER
    ******************************/
    void instantiateHttpServer();
    void registerRouteControllers(String route, String message);
#if defined(ESP8266)
    void registerRouteControllers(String route, void (*function)(ESP8266WebServer *server));
    void registerRouteControllers(String route, HTTPMethod method, void (*function)(ESP8266WebServer *server));
#elif defined(ESP32)
    void registerRouteControllers(String route, void (*function)(WebServer *server));
    void registerRouteControllers(String route, HTTPMethod method, void (*function)(WebServer *server));
#endif

    // Keep http server alive
    void handleServer();

private:
    char *_ssid = "";
    char *_pass = "";
    char *_ssidAP = "";
    char *_passAP = "";
    char wifiData[255];
    String parsedData = "";
    WiFiUDP udpSocket;
#if defined(ESP8266)
    ESP8266WebServer server;
#elif defined(ESP32)
    WebServer server;
#endif

    bool debug = false;
    String printFormat = "[WIFIM]: ";
    void debugPrint(String message);
};

#endif