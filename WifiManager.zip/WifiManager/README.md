# wifi_manager

Arduino library to simply manage Wifi, HTTP Methods, UDP Sockets and WiFi OTA Updates on ESP8266 and ESP32.

## Instantiate Class

To create an instace of a class you should use a pointer object after define the `#include` library header. Constructor have two constructors

### Instance without Debug

The default constructor create an instance of WifiManager without any debug mode enabled. 

```cpp
#include <WifiManager.h>

WifiManager* wifiManager;

void setup(){
    wifiManager = new WifiManager();
}
```

### Instance with Debug

This constructor requires a boolean parameter to set if debug mode will be enabled. If parameter is setted as `true` debug mode is enabled, but if parameter is setted as `false` debug mode is disabled

```cpp
#include <WifiManager.h>

WifiManager* wifiManager;

void setup(){
    wifiManager = new WifiManager(true);
}
```

## Open Access Point

To enable device as Access point you should use `CreateAP` function that receive the following parameters

| Name | Type | Description |
|------|------|-------------|
| SSID | `String` | The network SSID (name) to set |
| PASS | `String` | The network password to set|

### Example

```cpp
#include <WifiManager.h>

WifiManager* wifiManager;

// Define network information to create the AP
#define SSID "FLEXO_AP"
#define PASS "FLX900-3"

void setup(){
    Serial.begin(9600);
    wifiManager = new WifiManager(true);
    // Create the AP with network information stablished before.
    wifiManager->createAP(SSID, PASS);
}
```

## Connect to an existing network

To enable device as Station mode (Connect to existing network) you should use `connect` function that receive the following parameters.

| Name | Type | Description |
|------|------|-------------|
| SSID | `String` | The network SSID (name) to connect |
| PASS | `String` | The network password to connect |

### Example

```cpp
#include <WifiManager.h>

WifiManager *wifiManager;

//Define credentials for existing networ
#define SSID "FlexoLumens"
#define PASS "Flexo900742055"

void setup(){
    Serial.begin(9600);
    wifiManager = new WifiManager(true);
    // Connect to settet network
    wifiManager->connect(SSID, PASS);
}
```

### Check if is connected to setted network

To detect if ESP8266 or ESP32 is connected to the setter WiFi Network, you should use `ìsConnected` method. This method do not wait for parameters but returns a boolean. If return value es `true` device is connected to setted network, but if is `false` device is not connected to setter network.

#### Example

```csharp
void loop(){
    if(wifiManager->isConnected()){
        Serial.write(&"\nConectado"[0]);
    }else{
        Serial.write(&"\nNo Conectado"[0]);
    }
    delay(10000);
}
```

## Create UDP Server

To create an UDP Server, you should use `startUdpServer()` that requires port `int value` as paramameter. The value is the port when you are going to receive UDP Packets.

### Example
```
wifiManager->startUdpServer(9742);
```

### Listen for arriving data

To know if there is data that arrived through server, you should use `isDataAvailable` method, then if there is any data available you can read usign `getWifiData` or `getWifiDataInChars` methods.

| Method | Return Type | Description |
|------|------|-------------|
| `isDataAvailable` | `bool` | Returns if data is available -> true = available -> false = not available |
| `getWifiData` | `String` | Returns received data in String |
| `getWifiDataInChars` | `char*` | Returns received data in pure char array pointer |

#### Example

```cpp
void setup()
{
    wifiManager->createAP(SSID, PASS);
    wifiManager->startUdpServer(9742);
}

void loop()
{
    
    if (wifiManager->isDataAvailable())
    {
        String receivedUdpData = wifiManager->getWifiData();
        if (receivedUdpData.indexOf("FT-ROUTEª") >= 0)
        {
            //TODO: Some logic
        }
    }
}
```

### Send data to a client

To send data to a client you should use `sendData` method that receives the following parameters

| Name | Type | Description |
|------|------|-------------|
| IP Address | `String` | The destination IP Address |
| Port | `int` | The destination port |
| Data | `String` | Data to send to the destination |

## Create an HTTP Server

### Register API Route Controllers

To register custom routes and controller functions you should use one of the next methods

```c
void registerRouteControllers(String route, String message);
void registerRouteControllers(String route, void (*function)(WebServer* server));
void registerRouteControllers(String route, HTTPMethod method, void (*function)(WebServer* server));
```

### Instantiate server

After register your custom servers, yo need to instantiate server using `instantiateHTTPServer()` one time

### Handle Server

You should handle server during your loop using `handleServer` method

### Complete example

```cpp
#include <WifiManager.h>

WifiManager *wifiManager;

#define SSID "FLEXO_AP"
#define PASS "FLX900-3"

bool apCreated = false;
bool serverInstantiated = false;

void setup()
{
    Serial.begin(9600);
    wifiManager->startUdpServer(9742);
    wifiManager->registerRouteControllers("/", "Prueba Http");
    wifiManager->registerRouteControllers("/test", test);
    wifiManager->instantiateHttpServer();
}

void loop()
{
    wifiManager->handleServer();
}

void test(WebServer* server){
    Serial.write(&"Esta es una prueba"[0]);
    server->send(200, "text/plain", "Esta es una prueba con función");
}
```