#include "ElegantOTA.h"

ElegantOtaClass ElegantOTA;