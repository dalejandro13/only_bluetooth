#include "WifiManager.h"

WifiManager::WifiManager() : server(80)
{
  //Inicializa el modo de Wifi en apagado
  WiFi.mode(WIFI_OFF);
}

WifiManager::WifiManager(bool debug) : server(80)
{
  this->debug = debug;
  WifiManager();
  debugPrint("Debug mode enabled");
}

void WifiManager::connect(String networkSSID, String networkPASS)
{
  _ssid = (char *)networkSSID.c_str();
  _pass = (char *)networkPASS.c_str();
  WiFi.mode(WIFI_STA);
  WiFi.begin(_ssid, _pass);
  debugPrint("Connecting to " + String(_ssid) + " network.");
}

void WifiManager::connect(char* networkSSID, char* networkPASS)
{
  if(isConnected()){
    disconnect();
  }
  _ssid = networkSSID;
  _pass = networkPASS;
  WiFi.mode(WIFI_STA);
  WiFi.begin(_ssid, _pass);
  debugPrint("Connecting to " + String(_ssid) + " network.");
}

void WifiManager::disconnect()
{
  WiFi.disconnect();
  debugPrint("Disconnecting from " + String(_ssid) + " network.");
}

void WifiManager::createAP(String ssid, String pass)
{
  _ssidAP = (char *)ssid.c_str();
  _passAP = (char *)pass.c_str();
  WiFi.mode(WIFI_AP);
  IPAddress local_IP(192, 168, 2, 1);
  IPAddress gateway(192, 168, 2, 255);
  IPAddress subnet(255, 255, 255, 0);
  WiFi.softAPConfig(local_IP, gateway, subnet);
  WiFi.softAP(_ssidAP, _passAP, 6);
  debugPrint("Access Point " + String(_ssidAP) + " created.");
}

void WifiManager::createAP(char*  ssid, char*  pass)
{
  _ssidAP = ssid;
  _passAP = pass;
  WiFi.mode(WIFI_AP);
  IPAddress local_IP(192, 168, 2, 1);
  IPAddress gateway(192, 168, 2, 255);
  IPAddress subnet(255, 255, 255, 0);
  WiFi.softAPConfig(local_IP, gateway, subnet);
  WiFi.softAP(_ssidAP, _passAP, 6);
  debugPrint("Access Point " + String(_ssidAP) + " created.");
}

void WifiManager::debugPrint(String message)
{
  if (debug)
  {
    String msg = "\n" + printFormat + message;
    Serial.write(&msg[0]);
  }
}

bool WifiManager::isConnected()
{
  return WiFi.status() == WL_CONNECTED;
}

bool WifiManager::startUdpServer(unsigned int port)
{
  debugPrint("Starting UDP Server at port" + String(port));
  return udpSocket.begin(port);
}

bool WifiManager::isDataAvailable()
{
  memset(wifiData, 0, 256); // Limpiar el buffer antes de usarlo
  parsedData = "";
  int receivedPacked = udpSocket.parsePacket();
  if (receivedPacked > 0)
  {
    if (udpSocket.available() > 0)
    {
      int len = udpSocket.read(wifiData, 255);
      wifiData[len] = '\0';
      parsedData = String(wifiData);
      debugPrint("Received Data: " + parsedData);
    }
    // Serial.print("\nwifiData: " + String(wifiData));
    return true;
  }

  return false;
}

String WifiManager::getWifiData()
{
  return parsedData;
}

char *WifiManager::getWifiDataInChars()
{
  return wifiData;
}

void WifiManager::stopUdpServer()
{
  udpSocket.stop();
}

bool WifiManager::sendData(char *remoteIp, int remotePort, const byte *data, size_t size)
{
  if (udpSocket.beginPacket(remoteIp, remotePort) == 1)
  {
    int fSize = udpSocket.write(data, size);
    if (fSize != size)
    {
      udpSocket.write(data, size);
    }

    if (udpSocket.endPacket() == 1)
    {
      // yield();
      return true;
    }
    // yield();
  }
  return false;
}

bool WifiManager::sendData(char *remoteIp, int remotePort, String data)
{
  if (udpSocket.beginPacket(remoteIp, remotePort) == 1)
  {
    udpSocket.write((uint8_t *)data.c_str(), data.length());

    if (udpSocket.endPacket() == 1)
    {
      // yield();
      return true;
    }
    // yield();
  }
  return false;
}

void WifiManager::instantiateHttpServer()
{
  ElegantOTA.begin(&server); // Start ElegantOTA
  server.begin();
}

void WifiManager::registerRouteControllers(String route, String message)
{
  server.on(route, [this, message]()
            { this->server.send(200, "text/plain", message); });
}

#if defined(ESP8266)
void WifiManager::registerRouteControllers(String route, void (*function)(ESP8266WebServer *server))
{
#elif defined(ESP32)
void WifiManager::registerRouteControllers(String route, void (*function)(WebServer *server))
{
#endif

  server.on(route, [this, function]()
            { function(&server); });
}

#if defined(ESP8266)
void WifiManager::registerRouteControllers(String route, HTTPMethod method, void (*function)(ESP8266WebServer *server))
{
#elif defined(ESP32)
void WifiManager::registerRouteControllers(String route, HTTPMethod method, void (*function)(WebServer *server))
{
#endif
  server.on(route, method, [this, function]()
            { function(&server); });
}

void WifiManager::handleServer()
{
  server.handleClient();
}
